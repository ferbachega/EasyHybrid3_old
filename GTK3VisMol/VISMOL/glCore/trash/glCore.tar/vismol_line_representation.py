#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  vismol_line_representation.py
#  
#  Copyright 2017 Fernando Bachega <fernando@Fenrir>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  


import numpy as np
import math, copy
import ctypes
from OpenGL import GL

#import matrix_operations as mop
#import sphere_data as sphd
import VISMOL.glCore.sphere_data as sphd
import VISMOL.glCore.cylinder_data as cyd
import VISMOL.glCore.matrix_operations as mop

    
    

class LineRepresetation:
    """ Class doc """
    
    def __init__ (self, 
                  visObj      = None, 
                  program     = None,
                  
                  #bond_list   = None, 
                  #atom_list   = None,
                  ):
        
        """ Class initialiser """
        
        self.vao       = None
        self.ind_vbo   = None
        self.coord_vbo = None
        self.col_vbo   = None
        
        
        self.visObj  = visObj
        self.program = program
        
        self.bond_list = self.visObj.bonds
        self.atom_list = self.visObj.atoms
        
        
        
        #-------------------------------------------------------------------------
        self.coords = []
        self.colors = []
        for bond in self.bond_list:
            self.coords = np.hstack((self.coords, self.atom_list[bond[0]].pos))
            self.coords = np.hstack((self.coords, self.atom_list[bond[1]].pos))
            self.colors = np.hstack((self.colors, self.atom_list[bond[0]].color))
            self.colors = np.hstack((self.colors, self.atom_list[bond[1]].color))
        
        self.coords = np.array(self.coords, dtype=np.float32)
        self.colors = np.array(self.colors, dtype=np.float32)
        
        self.indexes = []
        for i in range(int(len(self.coords)/3)):
            self.indexes.append(i)
        self.indexes = np.array(self.indexes,dtype=np.uint32)
        #-------------------------------------------------------------------------
        
        #-------------------------------------------------------------------------
        # VAO
        self.vao = GL.glGenVertexArrays(1)
        GL.glBindVertexArray(self.vao)

        # VBO_ind
        self.ind_vbo = GL.glGenBuffers(1)
        GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, self.ind_vbo)
        
        GL.glBufferData(GL.GL_ELEMENT_ARRAY_BUFFER                  , 
                        self.indexes.itemsize*int(len(self.indexes)), 
                        self.indexes                                , 
                        GL.GL_DYNAMIC_DRAW)
        
        # VBO_coord
        self.coord_vbo = GL.glGenBuffers(1)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.coord_vbo)
        GL.glBufferData(GL.GL_ARRAY_BUFFER, self.coords.itemsize*int(len(self.coords)), self.coords, GL.GL_STATIC_DRAW)
        att_position = GL.glGetAttribLocation(self.program, 'vert_coord')
        GL.glEnableVertexAttribArray(att_position)
        GL.glVertexAttribPointer(att_position, 3, GL.GL_FLOAT, GL.GL_FALSE, 3*self.coords.itemsize, ctypes.c_void_p(0))

        # VBO_color
        self.col_vbo = GL.glGenBuffers(1)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.col_vbo)
        GL.glBufferData(GL.GL_ARRAY_BUFFER, self.colors.itemsize*int(len(self.colors)), self.colors, GL.GL_STATIC_DRAW)
        att_colors = GL.glGetAttribLocation(self.program, 'vert_color')
        GL.glEnableVertexAttribArray(att_colors)
        GL.glVertexAttribPointer(att_colors, 3, GL.GL_FLOAT, GL.GL_FALSE, 3*self.colors.itemsize, ctypes.c_void_p(0))
        
        #vao_list.append(vao)
        GL.glBindVertexArray(0)
        GL.glDisableVertexAttribArray(att_position)
        GL.glDisableVertexAttribArray(att_colors)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, 0)
        GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, 0)
        #-------------------------------------------------------------------------

 
    
    
    
    
    
    
    
    
    
    
    def make_gl_lines(program, bond_list, atom_list):

        vao = GL.glGenVertexArrays(1)
        GL.glBindVertexArray(vao)
        
        ind_vbo = GL.glGenBuffers(1)
        GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, ind_vbo)
        GL.glBufferData(GL.GL_ELEMENT_ARRAY_BUFFER, indexes.itemsize*int(len(indexes)), indexes, GL.GL_DYNAMIC_DRAW)
        
        coord_vbo = GL.glGenBuffers(1)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, coord_vbo)
        GL.glBufferData(GL.GL_ARRAY_BUFFER, coords.itemsize*int(len(coords)), coords, GL.GL_STATIC_DRAW)
        att_position = GL.glGetAttribLocation(program, 'vert_coord')
        GL.glEnableVertexAttribArray(att_position)
        GL.glVertexAttribPointer(att_position, 3, GL.GL_FLOAT, GL.GL_FALSE, 3*coords.itemsize, ctypes.c_void_p(0))
        
        col_vbo = GL.glGenBuffers(1)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, col_vbo)
        GL.glBufferData(GL.GL_ARRAY_BUFFER, colors.itemsize*int(len(colors)), colors, GL.GL_STATIC_DRAW)
        att_colors = GL.glGetAttribLocation(program, 'vert_color')
        GL.glEnableVertexAttribArray(att_colors)
        GL.glVertexAttribPointer(att_colors, 3, GL.GL_FLOAT, GL.GL_FALSE, 3*colors.itemsize, ctypes.c_void_p(0))
        
        #vao_list.append(vao)
        GL.glBindVertexArray(0)
        GL.glDisableVertexAttribArray(att_position)
        GL.glDisableVertexAttribArray(att_colors)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, 0)
        GL.glBindBuffer(GL.GL_ELEMENT_ARRAY_BUFFER, 0)
        
        return vao, (ind_vbo, coord_vbo, col_vbo)
