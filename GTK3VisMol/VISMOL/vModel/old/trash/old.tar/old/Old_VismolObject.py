#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  VismolObject.py
#  
#  Copyright 2017 
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  

import numpy as np
import time
import os
import multiprocessing as mp


import threading
#def worker(i):
#    """thread worker function"""
#    print('Worker', i)
#
##----------------------------------------
#threads = []
#for i in range(100000):
#    t = threading.Thread(target=worker(i))
#    threads.append(t)
#    t.start()
##----------------------------------------

from multiprocessing import Pool



#import VISMOL.Model.cfunctions as cfunctions
#import VISMOL.Model.Chain as Chain
from VISMOL.vModel.Chain      import Chain
from VISMOL.vModel.Residue    import Residue
from VISMOL.vModel.cfunctions import C_generate_bonds, C_generate_bonds2, C_generate_bonds_between_sectors
#from VISMOL.glCore.VismolRepresentations import LineRepresetation

#----------------------------------------------------
from scipy.spatial import distance
#import scipy as scipy
#----------------------------------------------------

#import VISMOL.Model as model



class VismolObject:
    """ Class doc """
    
    def __init__ (self, 
                  name       = 'UNK', 
                  atoms      = []   ,
                  coords     = None ,
                  VMSession  = None , 
                  trajectory = None):
        
        """ Class initialiser """
        
        self.vismol_session = VMSession
        self.actived        = False
        self.editing        = False
        self.Type           = 'molecule'
        self.name           = name #self._get_name(name)
        
        
        #-----------------------------------------------------------------
        self.x_coords   = coords[0]
        self.y_coords   = coords[1]
        self.z_coords   = coords[2]
        self.xyz_coords = coords[3]

        sum_x = sum(self.x_coords)
        sum_y = sum(self.y_coords)
        sum_z = sum(self.z_coords)
        total = len(self.x_coords)
        #-----------------------------------------------------------------
        self.mass_center    = np.array([sum_x / total,
                                        sum_y / total, 
                                        sum_z / total])
        # --------------------- Model size and cell ---------------------- 
        self.cell_max_x  = 0.0
        self.cell_max_y  = 0.0
        self.cell_max_z  = 0.0
        self.cell_min_x  = 0.0
        self.cell_min_y  = 0.0
        self.cell_min_z  = 0.0
        self.sector_size = 10 # It's the size of each grid element - size of a sector (A) angtrons
        
        self.sectors = {
                       # (0,0,0) : [atom1, atom2, ...] 
                       }
        
       
        #--------------------------------------------------------------
        self.sector_neighbors = []
        '''
        Contains all pairs of neighboring sectors that will be used to 
        calculate distances between atoms from  different sectors (this 
        list does not contain any pairs of repeated sectors)
        '''
        #--------------------------------------------------------------
        
        
        #-----------------------------------------------------------------
        self.sectors_arround = [
                               [ 1, 1, 1], # top level
                               [ 0, 1, 1], # top level
                               [-1, 1, 1], # top level
                               [-1, 0, 1], # top level
                               [ 0, 0, 1], # top level
                               [ 1, 0, 1], # top level
                               [-1,-1, 1], # top level
                               [ 0,-1, 1], # top level
                               [ 1,-1, 1], # top level
                               
                               #-------------------------
                               [ 1, 1, 0], # middle level 
                               [ 0, 1, 0], # middle level 
                               [-1, 0, 0], # middle level 
                               [-1, 1, 0], # middle level 
                              #[ 0, 0, 0], # middle level 
                               [ 1, 0, 0], # middle level 
                               [-1,-1, 0], # middle level 
                               [ 0,-1, 0], # middle level 
                               [ 1,-1, 0], # middle level 
                               #-------------------------
                               
                               [ 1, 1,-1], # ground level
                               [ 0, 1,-1], # ground level
                               [-1, 1,-1], # ground level
                               [-1, 0,-1], # ground level
                               [ 0, 0,-1], # ground level
                               [ 1, 0,-1], # ground level
                               [-1,-1,-1], # ground level
                               [ 0,-1,-1], # ground level
                               [ 1,-1,-1], # ground level
                               ]
        #-----------------------------------------------------------------
        
        
        
        
        
        
        #-----------------------------------------------------------------
        # 
        #-----------------------------------------------------------------
        self.atoms              = atoms
        self.residues           = []
        self.chains             = {}
                                
        self.bonds              = []
        self.frames             = trajectory

        self.atom_unique_id_dic = {}
        self.index_bonds        = []
        self.index_bonds_rep    = []
        self.non_bonded_atoms   = None
		
		
        self._generate_atomtree_structure()
        self._generate_atom_unique_color_id()
        self._generate_bonds()
        self._generate_non_bonded_list()
        
        #self._generate_colors()
        
        """   L I N E S   """
        self.lines_actived       = True
        self.lines_show_list     = True
        #self.line_representation = LineRepresetation (visObj = self)
        
        
        #self.line_representation = LineRepresentation(self)
        #self.line_representation.update()

        """   D O T S   """
        self.dots_actived = False

        """   C I R C L E S   """
        self.circles_actived = False

        #self.flat_sphere_representation = FlatSphereRepresentation(self)
        
        '''
        self.dot_vao       = None
        self.dot_ind_vbo   = None
        self.dot_coord_vbo = None
        self.dot_col_vbo   = None
        '''

        print ('frames:     ', len(self.frames))
        print ('frame size: ', len(self.frames[0]))
        
        
    
        # OpenGL attributes
        self.dots_vao        = None
        self.lines_vao       = None
        self.circles_vao     = None
        self.dot_buffers     = None
        self.line_buffers    = None
        self.circles_buffers = None
        self.dot_indexes     = None
        
        self.selection_dots_vao      = None
        self.selection_dot_buffers   = None
        
        self.model_mat = np.identity(4, dtype=np.float32)
        self.trans_mat = np.identity(4, dtype=np.float32)
        self.target    = None
        self.unit_vec  = None
        self.distance  = None
        self.step      = None

        self.picking_dots_vao      = None
        self.picking_dot_buffers   = None

    def generate_dot_indexes(self):
        """ Function doc
        """
        self.dot_indexes = []
        for i in range(int(len(self.atoms))):
            self.dot_indexes.append(i)
        self.dot_indexes = np.array(self.dot_indexes, dtype=np.uint32)
    
    def _generate_atomtree_structure (self):
        """ Function doc """

        #t = threading.Thread(target= self._distribute_atoms_by_sectors(self.x_coords, self.y_coords, self.z_coords))
        #t.start()
        initial          = time.time()
        self._distribute_atoms_by_sectors(self.x_coords, self.y_coords, self.z_coords)
        final = time.time() 
        print ('_distribute_atoms_by_sectors end -  total time: ', final - initial, '\n')
        
        
        print ('\ngenerate_chain_structure starting')
        initial          = time.time()
        
        parser_resi  = None
        parser_resn  = None
        chains_m     = {}
        frame        = []
        index        = 1
        
        for atom in self.atoms:
            atom.index   = index
            atom.atom_id = self.vismol_session.atom_id_counter
            atom.Vobject =  self
            
            if atom.chain in self.chains.keys():
                ch = self.chains[atom.chain]
           
            else:
                ch = Chain(name = atom.chain, label = 'UNK')
                self.chains[atom.chain] = ch
            
            if atom.resi == parser_resi:# and at_res_n == parser_resn:
                atom.residue = ch.residues[-1]
                ch.residues[-1].atoms.append(atom)
                frame.append([atom.pos[0],atom.pos[1],atom.pos[2]])

            else:
                residue = Residue(name=atom.resn, index=atom.resi, chain=atom.chain)
                atom.residue     = residue
                residue.atoms.append(atom)
                
                ch.residues.append(residue)
                frame.append([atom.pos[0],atom.pos[1],atom.pos[2]])
                parser_resi  = atom.resi
                parser_resn  = atom.resn


            if atom.name == 'CA':
                ch.backbone.append(atom)

            self.vismol_session.atom_dic_id[self.vismol_session.atom_id_counter] = atom
            index +=1
            self.vismol_session.atom_id_counter +=1
        
        #-----------------------------------------------------------------
        #                 distribute_atoms_by_sectors
        #-----------------------------------------------------------------
        #self._distribute_atoms_by_sectors(self.x_coords, self.y_coords, self.z_coords)
        #-----------------------------------------------------------------
        final = time.time() 
        print ('_generate_atomtree_structure end -  total time: ', final - initial, '\n')
        return True

    def _get_name (self, name):
        """ Function doc """
        self.name  = os.path.basename(name)
        #self.name  = name.split('.')
        #self.name  = self.name[0]
    
    def _generate_bonds (self):
        """ Function doc """
        
        
        '''
        #print ('\ngenerate_bonds starting')
        initial          = time.time()
        #self.index_bonds        = []
        #self.index_bonds_pairs  = []
        self.index_bonds, self.index_bonds_pairs = C_generate_bonds(self.atoms)
        final = time.time() 
        print ('generate_bonds I end -  total time: ', final - initial, '\n')
        #'''
        
        #----------------------------------------------------------------------
        #       Calculate distances between atoms in a sector
        #----------------------------------------------------------------------
        initial     =  time.time()
        for key in self.sectors:
            self.compute_distances(self.sectors[key], log = False)
        
        final = time.time()    
        print ('euclidian per sector finished total time: ', final - initial, '\n')
        #----------------------------------------------------------------------

        #threads = []
        #----------------------------------------------------------------------
        #       Calculate distances between atoms in neighboring sectors 
        #----------------------------------------------------------------------
        initial     =  time.time()
        
        #with Pool(8) as p:
        #    print(p.map(self.compute_distances_between_sectors_parallel, self.sector_neighbors))
        
        for neighbors in self.sector_neighbors:
            sector1 = neighbors[0]
            sector2 = neighbors[1]
            try:
                self.compute_distances_between_sectors (self.sectors[sector1], 
                                                        self.sectors[sector2])   
            except:
                print ('sector1:',sector1 ) 
                print ('sector2:',sector2 ) 
                pass
        final = time.time()    
        print ('_compute_bonds_scipy  between sectors total time: ', final - initial, '\n')
        #-----------------------------------------------------------------------
        
        '''
        for key in self.sectors:
            distances = None
            for sector in sectors_arround:
                if (key[0]+sector[0], 
                    key[1]+sector[1], 
                    key[2]+sector[2]) in self.sectors:
                        
                    self.compute_distances_between_sectors (self.sectors[key]   , 
                                                            self.sectors[(key[0]+sector[0],
                                                                          key[1]+sector[1],
                                                                          key[2]+sector[2])])
         
         '''

        #--------------------------------------------------------------------------------
        #'''

    
    
    def _generate_non_bonded_list (self):
        """ Function doc """
        self.non_bonded_atoms   =  []
        for atom in self.atoms:
            if atom.connected != []:
            #if atom.index -1 in self.index_bonds:
                pass
            else:
                self.non_bonded_atoms.append(atom.index -1)
        self.non_bonded_atoms = np.array(self.non_bonded_atoms, dtype=np.uint32)

    def _generate_atom_unique_color_id (self):
        self.color_indexes  = []
        self.colors         = []        
        self.vdw_dot_sizes  = []
        self.cov_dot_sizes  = []
#        self.atom_unique_id_dic     = {}

        """ Function doc """
        for atom in self.atoms:
            #-------------------------------------------------------
            #                     ID Colors
            #-------------------------------------------------------
            i = atom.atom_id
            r = (i & 0x000000FF) >>  0
            g = (i & 0x0000FF00) >>  8
            b = (i & 0x00FF0000) >> 16
           
            self.color_indexes.append(r/255.0)
            self.color_indexes.append(g/255.0)
            self.color_indexes.append(b/255.0)
            
            pickedID = r + g * 256 + b * 256*256
            #print (pickedID)
            self.vismol_session.atom_dic_id[pickedID] = atom
            
            #-------------------------------------------------------
            #                      Colors
            #-------------------------------------------------------
            self.colors.append(atom.color[0])        
            self.colors.append(atom.color[1])        
            self.colors.append(atom.color[2])   

            #-------------------------------------------------------
            #                      VdW list
            #-------------------------------------------------------
            self.vdw_dot_sizes.append(atom.vdw_rad)
            self.cov_dot_sizes.append(atom.cov_rad)

        self.color_indexes = np.array(self.color_indexes, dtype=np.float32)
        self.colors        = np.array(self.colors       , dtype=np.float32)    
        self.vdw_dot_sizes = np.array(self.vdw_dot_sizes, dtype=np.float32)
        self.cov_dot_sizes = np.array(self.cov_dot_sizes, dtype=np.float32)

    def _generate_colors  (self):
        """ Function doc """
        self.colors = []        
        for atom in self.atoms:
            #if atom.dots:
            #-------------------------------------------------------
            #                        D O T S
            #-------------------------------------------------------
            self.colors.append(atom.color[0])        
            self.colors.append(atom.color[1])        
            self.colors.append(atom.color[2])   
            #self.colors.append(atom.color[3])   

        self.colors  = np.array(self.colors, dtype=np.float32)
    
    def set_model_matrix(self, mat):
        """ Function doc
        """
        self.model_mat = np.copy(mat)
        return True
    
    def pos (self, frame = None):
        """ Function doc """
        
    def compute_distances (self, atoms, log = True):
        """ Function doc """
        #print ('\ngenerate_bonds  euclidian per sector starting')
        initial          = time.time()
        xyz_coords = []

        for atom in atoms:
            xyz_coords.append(
                               (atom.pos[0],
                                atom.pos[1],
                                atom.pos[2])
                              )
        if xyz_coords == []:
            pass
        else:
            distances  = distance.cdist(xyz_coords, xyz_coords, 'euclidean')
            
            for i in range(0, len(xyz_coords)):
                 
                for j in range(i+1, len(xyz_coords)):
                    
                    if distances[i][j] <= ((atoms[i].cov_rad + atoms[j].cov_rad)*1.3):
                        #self.index_bonds2.append([atom1.index -1, atom2.index -1])
                        self.index_bonds. append( atoms[i].index -1    )
                        self.index_bonds. append( atoms[j].index -1    )
                        atoms[i].connected.append(atoms[j])
                        atoms[j].connected.append(atoms[i])
        
        final = time.time() 
        if log:
            print ('generate_bonds  euclidian per sector finished -  total time: ', final - initial, '\n')
        


    def compute_distances_between_sectors_parallel (self, neighbors):
        sector1 = neighbors[0]
        sector2 = neighbors[1]
        try:
            #t = threading.Thread(target= self.compute_distances_between_sectors (self.sectors[sector1],
            #                                                                     self.sectors[sector2]))
            #threads.append(t)
            #t.start()
            self.compute_distances_between_sectors (self.sectors[sector1], 
                                                    self.sectors[sector2])   
        except:
            print ('sector1:',sector1 ) 
            print ('sector2:',sector2 ) 
            pass


   
    def compute_distances_between_sectors (self, atoms1, atoms2):
        """ Function doc """
        #initial     =  time.time()
        
        xyz_coords1 = []
        xyz_coords2 = []

        for atom1 in atoms1:
            xyz_coords1.append(
                               (atom1.pos[0],
                                atom1.pos[1],
                                atom1.pos[2])
                              )

        for atom2 in atoms2:
            xyz_coords2.append(
                               (atom2.pos[0],
                                atom2.pos[1],
                                atom2.pos[2])
                              )        
        
        if xyz_coords1 == [] or xyz_coords2 == []:
            pass
        
        else:
            distances  = distance.cdist( xyz_coords1, xyz_coords2, 'euclidean')
            if distances.min() <= 3.0:
                for i in range(0, len(distances)):   
                    for j in  range(0, len(distances[i])):
                        if distances[i][j] <=  (atoms1[i].cov_rad + atoms2[j].cov_rad)*1.3:
                            self.index_bonds. append( atoms1[i].index -1    )
                            self.index_bonds. append( atoms2[j].index -1    )
                            atoms1[i].connected.append(atoms2[j])
                            atoms2[j].connected.append(atoms1[i])
        
        #final = time.time()    
        #print ('_compute_bonds_scipy  between sectors total time: ', final - initial, '\n')
    
    def _distribute_atoms_by_sectors (self, x_coords, y_coords, z_coords, log= True):
        """ Function doc 
        self.sector_size = is the size of a grid element - size of a sector
        
        nX_windows = means the number of grid elements on the axis X
        nY_windows = means the number of grid elements on the axis Y
        nZ_windows = means the number of grid elements on the axis Z
        
        """
        
        #-----------------------------------------------------------------
        self.cell_max_x = max(x_coords)   
        self.cell_max_y = max(y_coords)   
        self.cell_max_z = max(z_coords)   
        self.cell_min_x = min(x_coords)  
        self.cell_min_y = min(y_coords)  
        self.cell_min_z = min(z_coords)  
        
        nx_windows = int((self.cell_max_x - self.cell_min_x)/ self.sector_size) +1 
        ny_windows = int((self.cell_max_y - self.cell_min_y)/ self.sector_size) +1 
        nz_windows = int((self.cell_max_z - self.cell_min_z)/ self.sector_size) +1 


        for i in range(0, nx_windows):
            for j in range(0, ny_windows):
                for k in range(0, nz_windows):
                    self.sectors[(i,j,k)] = []

        #-----------------------------------------------------------------
        for atom in self.atoms:
            a = int((atom.pos[0]  - self.cell_min_x) / self.sector_size)
            b = int((atom.pos[1]  - self.cell_min_y) / self.sector_size)
            c = int((atom.pos[2]  - self.cell_min_z) / self.sector_size)
            self.sectors[(a,b,c)].append(atom)
        #-----------------------------------------------------------------

        
        #-----------------------------------------------------------------------------
        # for all the sectors in self.sectors 
        #-----------------------------------------------------------------------------
        for key in self.sectors:
            
            for sector in self.sectors_arround:              
                #neighboring sector
                next_sector = (key[0]+sector[0], key[1]+sector[1], key[2]+sector[2])
                sector      = (key[0]          , key[1]          , key[2]          )
                #print ('next_sector: ', next_sector)
                #print ('sector     : ',      sector)

                #-----------------------------------------------------------------------------
                #Checking if the neighboring sector (next_sector) exists in the grid (sectors)
                #-----------------------------------------------------------------------------
                if next_sector in self.sectors:
                    #print (next_sector)
                    
                    if [next_sector, sector] in self.sector_neighbors or [sector, next_sector] in self.sector_neighbors:
                        pass
                    else:
                        #print ([sector, next_sector])
                        self.sector_neighbors.append([sector, next_sector])
        if log:
            print ('''
-----------------------------------------------------------------        
                        S E C T O R S  
-----------------------------------------------------------------        
''')
            
            print ('Sectors size      = ', self.sector_size)
            print ('cell_max_x        = ', self.cell_max_x )   
            print ('cell_max_y        = ', self.cell_max_y )   
            print ('cell_max_z        = ', self.cell_max_z )   
            print ('cell_min_x        = ', self.cell_min_x )  
            print ('cell_min_y        = ', self.cell_min_y )  
            print ('cell_min_z        = ', self.cell_min_z )  
            print ('nx_windows        = ', nx_windows)
            print ('ny_windows        = ', ny_windows)
            print ('nz_windows        = ', nz_windows)
            print ('Number of sectors = ', len(self.sectors))
            print ('''-----------------------------------------------------------------''')
            


def C_generate_bonds2_parallel(atoms):
    index_bonds, index_bonds_pairs = C_generate_bonds2(self.atoms)
    return [index_bonds, index_bonds_pairs]
    













